package com.ebanuty.mod;

import com.ebanuty.mod.item.VapeItem;
import com.ebanuty.mod.world.TreeGenerator;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.biome.Biome;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EbanutyMod implements ModInitializer {
    public static final String MOD_ID = "ebanuty";

    public static final Item POD_MINT = registerVape("pod_mint", "Мятный pod", 0x65D6A7, 1.0f);
    public static final Item DISPOSABLE_BERRY = registerVape("disposable_berry", "Ягодная одноразка", 0xD94B7A, 1.15f);
    public static final Item VAPE_PEN_COLA = registerVape("vape_pen_cola", "Cola vape pen", 0x7B4A2A, 1.35f);
    public static final Item BOX_MOD_MINT = registerVape("box_mod_mint", "Box mod", 0x8A8A9A, 1.65f);

    private static Item registerVape(String id, String name, int smokeColor, float intensity) {
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, id),
                new VapeItem(new Item.Settings().maxCount(1), name, smokeColor, intensity));
    }

    public static final RegistryKey<Biome> TINY_FOREST = RegistryKey.of(Registries.BIOME.getKey(), Identifier.of(MOD_ID, "tiny_forest"));
    public static final RegistryKey<Biome> GIANT_FOREST = RegistryKey.of(Registries.BIOME.getKey(), Identifier.of(MOD_ID, "giant_forest"));

    @Override
    public void onInitialize() {
        ServerChunkEvents.CHUNK_GENERATE.register((world, chunk) -> generateBiomeTrees(world, chunk));
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                CommandManager.literal("ebanuty")
                        .then(CommandManager.literal("tree")
                                .then(CommandManager.literal("tiny").executes(ctx -> {
                                    var p = ctx.getSource().getPlayerOrException();
                                    TreeGenerator.generateTiny(p.getWorld(), p.getBlockPos());
                                    ctx.getSource().sendFeedback(() -> Text.literal("Мини-дерево создано."), false);
                                    return 1;
                                }))
                                .then(CommandManager.literal("giant").executes(ctx -> {
                                    var p = ctx.getSource().getPlayerOrException();
                                    TreeGenerator.generateGiant(p.getWorld(), p.getBlockPos());
                                    ctx.getSource().sendFeedback(() -> Text.literal("100-блочное дерево создано."), false);
                                    return 1;
                                }))
                        )
                        .then(CommandManager.literal("vape").executes(ctx -> {
                            var p = ctx.getSource().getPlayerOrException();
                            p.getInventory().insertStack(new net.minecraft.item.ItemStack(BOX_MOD_MINT));
                            p.getInventory().insertStack(new net.minecraft.item.ItemStack(POD_MINT));
                            p.getInventory().insertStack(new net.minecraft.item.ItemStack(DISPOSABLE_BERRY));
                            p.getInventory().insertStack(new net.minecraft.item.ItemStack(VAPE_PEN_COLA));
                            ctx.getSource().sendFeedback(() -> Text.literal("Вейпы выданы."), false);
                            return 1;
                        }))
        ));
    }

    private static void generateBiomeTrees(net.minecraft.server.world.ServerWorld world, WorldChunk chunk) {
        var random = world.getRandom();
        int baseX = chunk.getPos().getStartX();
        int baseZ = chunk.getPos().getStartZ();
        // Several samples prevent a tree from being placed only at the chunk centre.
        for (int i = 0; i < 3; i++) {
            int x = baseX + random.nextInt(16);
            int z = baseZ + random.nextInt(16);
            int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            var pos = new net.minecraft.util.math.BlockPos(x, y, z);
            var biome = world.getBiome(pos);
            if (biome.matchesKey(TINY_FOREST) && random.nextFloat() < 0.55f) {
                TreeGenerator.generateTiny(world, pos);
            } else if (biome.matchesKey(GIANT_FOREST) && random.nextFloat() < 0.22f) {
                TreeGenerator.generateGiant(world, pos);
            }
        }
    }
}
