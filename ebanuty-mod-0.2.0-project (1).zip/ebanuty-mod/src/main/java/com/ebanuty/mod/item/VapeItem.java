package com.ebanuty.mod.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class VapeItem extends Item {
    private static final int MAX_PUFF_TICKS = 160; // 8 seconds
    private final String displayName;
    private final int smokeColor;
    private final float intensity;

    public VapeItem(Settings settings, String displayName, int smokeColor, float intensity) {
        super(settings);
        this.displayName = displayName;
        this.smokeColor = smokeColor;
        this.intensity = intensity;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        user.setCurrentHand(hand);
        if (!world.isClient) {
            world.playSound(null, user.getX(), user.getY(), user.getZ(),
                    SoundEvents.FIRE_EXTINGUISH, user.getSoundCategory(), 0.35f, 1.7f);
        }
        return TypedActionResult.consume(stack);
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) {
        return MAX_PUFF_TICKS;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        int heldTicks = MAX_PUFF_TICKS - remainingUseTicks;
        if (world.isClient && user instanceof PlayerEntity) {
            // Smoke grows continuously while the button is held.
            int particles = Math.min(1 + heldTicks / 12, 10);
            for (int i = 0; i < particles; i++) {
                double spread = 0.06 + heldTicks * 0.0008;
                world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        user.getX() + (world.random.nextDouble() - 0.5) * spread,
                        user.getEyeY() - 0.15,
                        user.getZ() + (world.random.nextDouble() - 0.5) * spread,
                        (world.random.nextDouble() - 0.5) * 0.015,
                        0.025 + heldTicks * 0.00015,
                        (world.random.nextDouble() - 0.5) * 0.015);
            }
        }
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        int heldTicks = Math.max(1, Math.min(MAX_PUFF_TICKS, MAX_PUFF_TICKS - remainingUseTicks));
        float seconds = heldTicks / 20.0f;
        float dose = Math.min(1.0f, seconds / 8.0f) * intensity;

        if (!world.isClient && user instanceof PlayerEntity player) {
            // Stronger and longer puffs produce progressively stronger nausea.
            int nauseaLevel = Math.max(0, (int) Math.floor(dose * 3.0f) - 1);
            int nauseaDuration = Math.max(20, (int) (35 + dose * 85));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, nauseaDuration, nauseaLevel));

            // Slowness gives a simple "dizziness" gameplay effect in the first MVP.
            int dizzyLevel = Math.max(0, (int) Math.floor(dose * 2.0f) - 1);
            int dizzyDuration = Math.max(20, (int) (25 + dose * 70));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, dizzyDuration, dizzyLevel));

            // The final exhale is proportional to the puff length.
            int finalParticles = Math.min(55, 5 + heldTicks / 3);
            for (int i = 0; i < finalParticles; i++) {
                double angle = world.random.nextDouble() * Math.PI * 2;
                double radius = world.random.nextDouble() * (0.15 + seconds * 0.07);
                ((net.minecraft.server.world.ServerWorld) world).spawnParticles(
                        ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        player.getX() + Math.cos(angle) * radius,
                        player.getEyeY() - 0.2,
                        player.getZ() + Math.sin(angle) * radius,
                        1, 0.02, 0.03 + seconds * 0.01, 0.02, 0.015 + seconds * 0.004);
            }
        }
    }

    public String displayName() { return displayName; }
    public int smokeColor() { return smokeColor; }
}
