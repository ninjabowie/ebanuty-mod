package com.ebanuty.mod.client;

import com.ebanuty.mod.EbanutyMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.text.Text;

public class EbanutyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (stack.getItem() == EbanutyMod.POD_MINT || stack.getItem() == EbanutyMod.DISPOSABLE_BERRY
                    || stack.getItem() == EbanutyMod.VAPE_PEN_COLA || stack.getItem() == EbanutyMod.BOX_MOD_MINT) {
                lines.add(Text.literal("ПКМ — держать для затяжки"));
                lines.add(Text.literal("Чем дольше держишь, тем больше дыма и эффектов"));
            }
        });
    }
}
