package com.ebanuty.mod.world;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public final class TreeGenerator {
    private TreeGenerator() {}

    public static void generateTiny(World world, BlockPos origin) {
        BlockPos base = origin.down();
        if (!world.getBlockState(base).isSolidBlock(world, base)) return;
        Random r = world.getRandom();
        int height = 2 + r.nextInt(3);
        for (int y = 0; y < height; y++) set(world, origin.up(y), Blocks.OAK_LOG.getDefaultState());
        BlockPos top = origin.up(height);
        set(world, top, Blocks.OAK_LEAVES.getDefaultState());
        if (height >= 3) {
            set(world, top.north(), Blocks.OAK_LEAVES.getDefaultState());
            set(world, top.south(), Blocks.OAK_LEAVES.getDefaultState());
            set(world, top.east(), Blocks.OAK_LEAVES.getDefaultState());
            set(world, top.west(), Blocks.OAK_LEAVES.getDefaultState());
        }
    }

    public static void generateGiant(World world, BlockPos origin) {
        BlockPos base = origin.down();
        if (!world.getBlockState(base).isSolidBlock(world, base)) return;
        Random r = world.getRandom();
        int height = 90 + r.nextInt(31); // 90-120 blocks
        int trunkRadius = 2 + r.nextInt(2);
        for (int y = 0; y < height; y++) {
            float taper = 1.0f - (y / (float) height) * 0.35f;
            int radius = Math.max(1, Math.round(trunkRadius * taper));
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz <= radius * radius + 1) {
                        set(world, origin.add(dx, y, dz), Blocks.OAK_LOG.getDefaultState());
                    }
                }
            }

            // Large branches begin above the lower third.
            if (y > height * 0.35 && y % (8 + r.nextInt(8)) == 0) {
                int branches = 3 + r.nextInt(3);
                for (int b = 0; b < branches; b++) {
                    double a = (Math.PI * 2 * b / branches) + r.nextDouble() * 0.5;
                    int length = 6 + r.nextInt(13);
                    for (int n = 1; n <= length; n++) {
                        int x = (int) Math.round(Math.cos(a) * n);
                        int z = (int) Math.round(Math.sin(a) * n);
                        set(world, origin.add(x, y + n / 3, z), Blocks.OAK_LOG.getDefaultState());
                    }
                }
            }
        }

        // Huge crown.
        BlockPos crown = origin.up(height);
        int crownRadius = 10 + r.nextInt(9);
        int crownHeight = 8 + r.nextInt(7);
        for (int dy = -crownHeight; dy <= crownHeight; dy++) {
            float layer = 1.0f - Math.abs(dy) / (float) (crownHeight + 1);
            int radius = Math.max(2, (int) (crownRadius * layer));
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz <= radius * radius) {
                        set(world, crown.add(dx, dy, dz), Blocks.OAK_LEAVES.getDefaultState());
                    }
                }
            }
        }
    }

    private static void set(World world, BlockPos pos, BlockState state) {
        if (world.getWorldBorder().contains(pos) && (world.isAir(pos) || state.isOf(Blocks.OAK_LEAVES) || state.isOf(Blocks.OAK_LOG))) {
            world.setBlockState(pos, state);
        }
    }
}
