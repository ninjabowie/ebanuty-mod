# Ebanuty Mod 0.2.0

Minecraft Java Edition **1.21.10**, Fabric, Java 21.

## What is implemented

### Ebanuty World
The mod adds an **Ebanuty World** world preset. Its Overworld uses Minecraft's checkerboard biome source, so newly generated terrain alternates between two custom biomes. The checkerboard scale is 5 (large regions rather than tiny patches).

- `ebanuty:tiny_forest` — absurdly small trees, 2–4 blocks high.
- `ebanuty:giant_forest` — absurdly large trees, 90–120 blocks high, with thick trunks, branches and a large crown.
- Trees are generated on `CHUNK_GENERATE`, so they are generated only when a chunk is newly created rather than every time it loads.

### Vape system
Four device variants are included:

- Mint Pod
- Berry Disposable
- Cola Vape Pen
- Mint Box Mod

Hold right mouse button to inhale. The puff duration is measured up to 8 seconds.

Longer puffs produce:

- more continuous smoke particles;
- a larger final exhale;
- stronger nausea;
- stronger slow/dizziness gameplay effect.

The devices have different intensity multipliers and different models/textures.

## Test commands

`/ebanuty vape` — gives all four vapes.

`/ebanuty tree tiny` — places a tiny tree at the player.

`/ebanuty tree giant` — places a random 90–120 block giant tree at the player.

## Build

The project is configured for Fabric 1.21.10 and Java 21. Fabric Loom downloads Minecraft, mappings and dependencies during setup/build.

A GitHub Actions workflow is included at `.github/workflows/build.yml`. If the repository is pushed to GitHub, the workflow builds the mod with Java 21 and uploads the resulting JAR as an Actions artifact. This is useful if the development PC cannot install a JDK.

## Important

The source project has been prepared as a near-release development build, but this environment cannot download Gradle/Minecraft dependencies, so the final JAR has **not** been compiled here. Do not treat a source ZIP as a compiled mod.
